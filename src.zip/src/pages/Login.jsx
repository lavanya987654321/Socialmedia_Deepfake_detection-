import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Header from '../components/Header'
import Footer from '../components/Footer'

function Login() {
  const navigate = useNavigate()
  const [isSignup, setIsSignup] = useState(false)

  function handleSubmit(e) {
    e.preventDefault()
    // Dummy login/signup - in real app you'd call API
    navigate('/upload')
  }

  function handleTrialClick() {
    navigate('/upload')
  }

  return (
    <div className="h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex flex-col">
      <Header />
      
      <main className="flex-1 overflow-y-auto flex items-center justify-center p-8">
        <div className="max-w-md w-full bg-white/95 backdrop-blur rounded-2xl shadow-2xl border-2 border-gray-200 p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">
              {isSignup ? 'Create Account' : 'Welcome Back'}
            </h2>
            <p className="text-gray-600 mt-2">
              {isSignup ? 'Sign up to start detecting deepfakes' : 'Log in to continue your analysis'}
            </p>
          </div>

          <div className="mb-6 bg-gradient-to-br from-sky-50 to-blue-50 p-5 rounded-xl border border-sky-200">
            <div className="flex items-center gap-2 mb-2">
              <svg className="w-5 h-5 text-sky-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <h3 className="font-semibold text-sky-900">Free Trial Available</h3>
            </div>
            <p className="text-sm text-gray-700 mb-3">Maximum 5 uploads. Data stored locally in your browser.</p>
            <button 
              onClick={handleTrialClick} 
              className="text-sm text-sky-700 hover:text-sky-800 font-medium underline underline-offset-2"
            >
              Continue without account (Trial) →
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignup && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <input 
                  name="name" 
                  type="text"
                  placeholder="John Doe" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none transition"
                  required
                />
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
              <input 
                name="email" 
                type="email"
                placeholder="you@example.com" 
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none transition"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Password</label>
              <input 
                name="password" 
                type="password" 
                placeholder="••••••••" 
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none transition"
                required
              />
            </div>

            {isSignup && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                <input 
                  name="confirmPassword" 
                  type="password" 
                  placeholder="••••••••" 
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-transparent outline-none transition"
                  required
                />
              </div>
            )}

            <button 
              type="submit" 
              className="w-full bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white font-semibold px-6 py-3 rounded-lg shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all duration-200"
            >
              {isSignup ? 'Create Account' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button 
              onClick={() => setIsSignup(!isSignup)}
              className="text-sm text-gray-600 hover:text-sky-600 transition-colors"
            >
              {isSignup ? 'Already have an account? ' : "Don't have an account? "}
              <span className="font-semibold text-sky-600">
                {isSignup ? 'Sign In' : 'Sign Up'}
              </span>
            </button>
          </div>

          <div className="mt-8 pt-6 border-t border-gray-200">
            <div className="text-xs text-gray-500 text-center">
              By continuing, you agree to our Terms of Service and Privacy Policy
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}

export default Login
