import Header from '../components/Header'
import Footer from '../components/Footer'
import UploadArea from '../components/UploadArea'

export default function Upload() {
  return (
    <div className="h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex flex-col">
      <Header />
      
      <main className="flex-1 overflow-y-auto p-8">
        <div className="w-full max-w-5xl mx-auto">
          <div className="mb-6">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">
              Upload & Analyze
            </h2>
            <p className="text-gray-600 mt-2">Upload your video to detect potential deepfake manipulation</p>
          </div>
          
          <div className="bg-white/95 backdrop-blur-sm shadow-xl rounded-2xl p-8 border border-gray-200">
            <UploadArea />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
