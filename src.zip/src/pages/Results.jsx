import { useLocation } from 'react-router-dom'

function Results() {
  const loc = useLocation()
  const data = loc.state

  const img = (p) => `http://127.0.0.1:5000/outputs/${p}?t=${Date.now()}`

  return (
    <div className="min-h-screen bg-gray-100 p-8">

      <h1 className="text-4xl font-bold text-blue-700 mb-6">
        Deepfake Detection Dashboard
      </h1>

      <div className="grid grid-cols-2 gap-6">

        {/* LEFT SIDE */}
        <div className="space-y-6">

          {/* MODEL CARD */}
          <div className="bg-white p-6 rounded-xl shadow">
            <h2 className="text-lg font-semibold mb-4">Model Assessment</h2>

            <div className="flex justify-between">
              <div>
                <p className="text-gray-500">Result</p>
                <p className={`text-3xl font-bold ${data.result === "REAL" ? "text-green-600" : "text-red-600"}`}>
                  {data.result}
                </p>
              </div>

              <div>
                <p className="text-gray-500">Confidence</p>
                <p className={`text-3xl font-bold ${data.result === "REAL" ? "text-green-600" : "text-red-600"}`}>
                  {data.confidence}%
                </p>
              </div>
            </div>

           <p className="mt-4 text-sm text-gray-600">
              Confidence indicates how strongly the model believes the prediction.
              {data.result === "REAL"
              ? " Lower values suggest the content is likely authentic."
              : " Higher values indicate a high probability of manipulation."}
            </p>
          </div>

          {/* FRAMES */}
          <Section title="📸 Extracted Frames">
            {data.frames.map((f,i)=>(
              <Card key={i} src={img(f)} label={`Frame ${i+1}`} />
            ))}
          </Section>

          {/* FACES */}
          <Section title="🙂 Detected Faces">
            {data.faces.map((f,i)=>(
              <Card key={i} src={img(f)} label={`Face ${i+1}`} />
            ))}
          </Section>

          {/* HEATMAP */}
          <Section title="🔥 GradCAM Heatmaps">
            {data.gradcam.map((f,i)=>(
              <Card key={i} src={img(f)} label={`Heatmap ${i+1}`} />
            ))}
          </Section>

        </div>

        {/* RIGHT SIDE */}
        <div className="space-y-6">

          <Info title="📌 Interpretation">
            The model identified spatial inconsistencies and abnormal texture patterns,
            suggesting potential manipulation. Facial distortions and irregular lighting
            transitions were detected across multiple frames.
          </Info>

          <Info title="📊 Analysis Insights">
            Frame-wise analysis shows irregular motion continuity and blending artifacts.
            Facial regions exhibit over-smoothing and unnatural sharpness in certain areas.
            These indicators align with known deepfake generation techniques.
          </Info>

          <Info title="🧠 System Explanation">
            This system uses CNN-based feature extraction combined with GradCAM
            visualization to highlight regions influencing prediction. It ensures
            transparency and interpretability in deepfake detection.
          </Info>

          <div className="bg-blue-600 text-white p-5 rounded-xl shadow">
            <h3 className="font-semibold">System Info</h3>
            <p className="text-sm mt-2">
              Powered by CNN + GradCAM for explainable AI deepfake detection.
            </p>
          </div>

          {/* ✅ NEW EXTRA CARD (ONLY ADDITION) */}
          <Info title="🌐 About This Platform">
            This platform provides AI-powered deepfake detection using advanced
            computer vision and explainability techniques. It analyzes frames,
            detects facial inconsistencies, and highlights manipulated regions
            using GradCAM. The goal is to ensure reliable media verification
            and improve trust in digital content.
          </Info>

        </div>

      </div>

      <button
        onClick={() => window.open("http://127.0.0.1:5000/download-report")}
        className="mt-6 bg-blue-600 text-white px-6 py-2 rounded"
      >
        Download PDF Report
      </button>

    </div>
  )
}

function Section({title, children}) {
  return (
    <div className="bg-white p-5 rounded-xl shadow">
      {/* ✅ Slightly improved label visibility */}
      <h3 className="font-semibold text-lg text-gray-800 mb-3">{title}</h3>
      <div className="flex gap-4 flex-wrap">{children}</div>
    </div>
  )
}

function Card({src,label}) {
  return (
    <div className="text-center">
      <img src={src} className="w-40 h-48 object-cover rounded border"/>
      <p className="text-xs mt-1">{label}</p>
    </div>
  )
}

function Info({title, children}) {
  return (
    <div className="bg-white p-5 rounded-xl shadow">
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-gray-600 mt-2">{children}</p>
    </div>
  )
}

export default Results