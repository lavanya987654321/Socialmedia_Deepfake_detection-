import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import ProgressPipeline from './ProgressPipeline'

function UploadArea() {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [running, setRunning] = useState(false)
  const navigate = useNavigate()

  // Initialize free uploads counter
  useEffect(() => {
    const key = 'freeUploadsRemaining'
    if (localStorage.getItem(key) === null) {
      localStorage.setItem(key, '5')
    }
  }, [])

  // Preview file
  useEffect(() => {
    if (!file) return
    const url = URL.createObjectURL(file)
    setPreview(url)
    return () => URL.revokeObjectURL(url)
  }, [file])

  function handleFile(e) {
    const f = e.target.files?.[0]
    if (f) setFile(f)
  }

  // 🔥 MAIN FUNCTION
  async function startAnalysis() {
    if (!file) return

    const key = 'freeUploadsRemaining'
    const remaining = parseInt(localStorage.getItem(key) || '0', 10)

    if (remaining <= 0) {
      alert('No free uploads remaining. Please sign up to continue.')
      return
    }

    localStorage.setItem(key, String(Math.max(0, remaining - 1)))
    setRunning(true)

    try {
      const formData = new FormData()
      formData.append("file", file)

      console.log("Sending file to backend...")

      // ✅ FIXED ENDPOINT
      const response = await fetch("http://127.0.0.1:5000/upload", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`)
      }

      const data = await response.json()
      console.log("Backend response:", data)

      if (!data || !data.result) {
        throw new Error("Invalid response from backend")
      }

      const result = {
        filename: file.name,
        confidence: data.confidence,
        result: data.result,
        frames: data.frames || [],
        faces: data.faces || [],
        gradcam: data.gradcam || [],
        timestamp: new Date().toISOString()
      }

      setRunning(false)
      navigate('/results', { state: result })

    } catch (error) {
      console.error("FULL ERROR:", error)

      alert("Backend connection failed.\n\nCheck:\n1. Backend running\n2. No errors in terminal\n3. Correct API URL")

      setRunning(false)
    }
  }

  return (
    <div className="space-y-6">

      <div className="text-sm text-gray-600">
        Upload an video to analyze for deepfake detection
      </div>

      <label className="flex flex-col items-center justify-center border-2 border-dashed border-sky-300 rounded-2xl p-12 bg-sky-50 cursor-pointer hover:border-sky-500 transition">
        <input type="file" accept="image/*,video/*" className="hidden" onChange={handleFile} />
        <div className="text-center">
          <div className="text-sky-700 font-semibold text-lg">
            Click or drag file here
          </div>
          <div className="text-sm text-gray-500 mt-2">
            MP4
          </div>
        </div>
      </label>

      {preview && (
        <div className="border p-4 rounded-xl bg-white">
          {file.type.startsWith('video') ? (
            <video src={preview} controls className="w-full rounded" />
          ) : (
            <img src={preview} alt="preview" className="w-full rounded" />
          )}

          <div className="mt-2 flex justify-between">
            <div className="text-sm">{file.name}</div>
            <button onClick={() => setFile(null)} className="text-red-500">
              Remove
            </button>
          </div>
        </div>
      )}

      <button
        onClick={startAnalysis}
        disabled={running || !file}
        className="bg-blue-600 text-white px-6 py-2 rounded disabled:bg-gray-400"
      >
        {running ? 'Analyzing...' : 'Analyze'}
      </button>

      <div className="text-sm text-gray-600">
        Remaining uploads: {localStorage.getItem('freeUploadsRemaining') || '0'} / 5
      </div>

      {running && <ProgressPipeline data={{ stepName: "Processing...", pct: 50 }} />}

    </div>
  )
}

export default UploadArea