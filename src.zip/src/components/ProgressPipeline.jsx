function ProgressPipeline({ data }) {
  const { pct = 0, stepName = '', step = 0 } = data || {}
  return (
    <div className="mt-6 p-6 bg-gradient-to-br from-sky-50 to-blue-50 rounded-2xl border-2 border-sky-200 shadow-lg">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-sky-600 rounded-xl flex items-center justify-center animate-pulse">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <div>
          <div className="text-sm font-semibold text-gray-700">Processing Analysis</div>
          <div className="text-xs text-gray-500">{stepName}</div>
        </div>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden shadow-inner">
        <div 
          className="h-full bg-gradient-to-r from-sky-500 to-blue-600 rounded-full transition-all duration-500 ease-out shadow-lg"
          style={{ width: `${pct}%` }}
        ></div>
      </div>
      
      <div className="mt-3 flex justify-between items-center text-xs">
        <span className="text-gray-600 font-medium">Step {step} of 5</span>
        <span className="text-sky-700 font-bold text-sm">{pct}%</span>
      </div>
    </div>
  )
}

export default ProgressPipeline
