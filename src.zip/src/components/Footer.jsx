export default function Footer() {
  return (
    <footer className="w-full bg-white/95 backdrop-blur-sm border-t border-gray-200">
      <div className="w-full px-6 py-4 flex items-center justify-between">
        <div className="text-sm text-gray-600">
          © {new Date().getFullYear()} <span className="font-semibold text-sky-600">DeepGuard</span>
        </div>
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <span className="flex items-center gap-1">
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
            </svg>
            Built for demo
          </span>
          <span>·</span>
          <span>AI-Powered Detection</span>
        </div>
      </div>
    </footer>
  )
}
