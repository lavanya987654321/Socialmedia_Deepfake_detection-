export default function Header() {
  return (
    <header className="w-full bg-white/95 backdrop-blur-sm border-b border-gray-200 shadow-sm">
      <div className="w-full px-6 py-4 flex items-center justify-center">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-sky-600 to-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-lg shadow-lg">
            DG
          </div>
          <div>
            <div className="text-xl font-bold bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent">
              DeepGuard
            </div>
            <div className="text-xs text-gray-500 font-medium">AI Deepfake Detection</div>
          </div>
        </div>
      </div>
    </header>
  )
}
